<template>

</template>

<script>
    export default {
        name: "Money"
    }
</script>

<style scoped>

</style>
